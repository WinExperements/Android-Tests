package com.gg.can2;

import android.app.*;
import android.os.*;
import android.content.*;

public class ErrorActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		AlertDialog.Builder b = new AlertDialog.Builder(this);
		b.setTitle("Error");
		b.setMessage(getIntent().getStringExtra("error"));
		b.setPositiveButton("OK", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface p1, int p2)
				{
					finish();
				}
			});
		b.setCancelable(false);
		b.show();
	}
}
