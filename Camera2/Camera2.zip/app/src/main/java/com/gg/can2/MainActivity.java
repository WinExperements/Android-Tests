package com.gg.can2;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.projection.*;
import android.os.*;
import android.view.*;
import android.util.*;
import java.io.*;
import android.widget.*;

public class MainActivity extends Activity implements TextureView.SurfaceTextureListener
{

	@Override
	public void onSurfaceTextureAvailable(SurfaceTexture p1, int p2, int p3)
	{
		DisplayMetrics m = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(m);
		w = m.widthPixels;
		h = m.heightPixels;
		p1.setDefaultBufferSize(w,h);
		inputSurf = new Surface(p1);
		startActivityForResult(mgr.createScreenCaptureIntent(),1000);
	}

	@Override
	public void onSurfaceTextureSizeChanged(SurfaceTexture p1, int p2, int p3)
	{
		// TODO: Implement this method
	}

	@Override
	public boolean onSurfaceTextureDestroyed(SurfaceTexture p1)
	{
		// TODO: Implement this method
		return false;
	}

	@Override
	public void onSurfaceTextureUpdated(SurfaceTexture p1)
	{
		
	}
	
	private TextureView v;
	private Surface inputSurf;
	private MediaProjectionManager mgr;
	private VirtualDisplay displ;
	private MediaProjection pr;
	private int w,h;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        setContentView(R.layout.main);
		v = (TextureView) findViewById(R.id.mainSurfaceView);
		mgr = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
		v.setSurfaceTextureListener(this);
    }

	@Override
	public void onBackPressed()
	{
		if (displ != null) {
			displ.release();
			pr.stop();
		}
		finish();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (requestCode == 1000 && resultCode == RESULT_OK) {
			pr = mgr.getMediaProjection(resultCode,data);
			displ = pr.createVirtualDisplay("SurfTexDispl",w,h,1,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,inputSurf,null,null);
		}
	}
}
