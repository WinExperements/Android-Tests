package com.gg.can2;

import android.app.*;
import android.content.*;
import java.io.*;

public class MyApp extends Application
{

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {

				@Override
				public void uncaughtException(Thread p1, Throwable p2)
				{
					p2.printStackTrace();
					StringWriter wt = new StringWriter();
					p2.printStackTrace(new PrintWriter(wt));
					PendingIntent i = PendingIntent.getActivity(getApplicationContext(),100,new Intent(getApplicationContext(),ErrorActivity.class).putExtra("error",wt.toString()),PendingIntent.FLAG_ONE_SHOT);
					((AlarmManager)getSystemService(ALARM_SERVICE)).set(AlarmManager.RTC,System.currentTimeMillis(),i);
					android.os.Process.killProcess(android.os.Process.myPid());
				}
			});
	}
}
